#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  1 14:39:05 2021

@author: melikedila
"""

#####    Readings and the plots

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  
    
    
with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)      
    
    
with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  
    
    
with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  
    
    
with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)      
    
    
with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  
    
    
with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  


with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)  

with open("Desktop/design_dict_NMMSO1.txt", "rb") as fp:   
    design_dict_NMMSO1 = pickle.load(fp)    





###########   frequency plots - bar chart






##########  boxplots




##########  PCPs         
    